define(
"dojo/cldr/nls/nl/currency", //begin v1.x content
{
	"HKD_displayName": "Hongkongse dollar",
	"CHF_displayName": "Zwitserse frank",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Canadese dollar",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Chinese yuan renminbi",
	"USD_symbol": "US$",
	"AUD_displayName": "Australische dollar",
	"JPY_displayName": "Japanse yen",
	"CAD_symbol": "C$",
	"USD_displayName": "Amerikaanse dollar",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Brits pond sterling",
	"AUD_symbol": "AU $",
	"EUR_displayName": "Euro"
}
//end v1.x content
);